# -*- coding: utf-8 -*-
#------------------------------------------------------------
# palcoTV - XBMC Add-on by Juarrox (juarrox@gmail.com)
# Version 0.2.5 (15.05.2014)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)


import os
import sys
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import plugintools


art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.palcotv/art', ''))
playlists = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.palcotv/playlists', ''))
icon = art + 'icon.png'
fanart = art + 'fanart.png'


# Entry point
def run():

    # icon = 'icon.png'
    # fanart = 'fanart.png'
    
    plugintools.log("---> palcoTV.run <---")
    plugintools.set_view(plugintools.LIST)
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
       action = params.get("action")
       url = params.get("url")
       exec action+"(params)"

    plugintools.close_item_list()
       
  
# Main menu

def main_list(params):
    plugintools.log("palcoTV.main_list "+repr(params))
    data = plugintools.read("https://dl.dropboxusercontent.com/u/8036850/palcotv.xml")

    matches = plugintools.find_multiple_matches(data,'<menu_info>(.*?)</menu_info>')
    for entry in matches:
        title = plugintools.find_single_match(entry,'<title>(.*?)</title>')
        date = plugintools.find_single_match(entry,'<date>(.*?)</date>')
        plugintools.add_item( action="" , title = title + date , fanart = art+'fanart.png' , thumbnail=art+'icon.png' , folder = False , isPlayable = False )

    data = plugintools.read("https://dl.dropboxusercontent.com/u/8036850/palcotv.xml")
    
    matches = plugintools.find_multiple_matches(data,'<channel>(.*?)</channel>')
    for entry in matches:
        title = plugintools.find_single_match(entry,'<name>(.*?)</name>')
        thumbnail = plugintools.find_single_match(entry,'<thumbnail>(.*?)</thumbnail>')
        fanart = plugintools.find_single_match(entry,'<fanart>(.*?)</fanart>')
        action = plugintools.find_single_match(entry,'<action>(.*?)</action>')
        last_update = plugintools.find_single_match(entry,'<last_update>(.*?)</last_update>')
        url = plugintools.find_single_match(entry,'<url>(.*?)</url>')
        date = plugintools.find_single_match(entry,'<last_update>(.*?)</last_update>')
        if thumbnail == 'new.png':
            fixed = title
            plugintools.add_item( action = action , plot = fixed , title = '[B][COLOR lightyellow]' + fixed + '[COLOR lightyellow][/B][I] Nuevo![/COLOR][/I]' , fanart = art+'fanart.png' , thumbnail = art + 'new.png' , url = url , folder = True , isPlayable = False )
        else:
            if thumbnail == 'm3u.png':  # Control para listas M3U
                fixed = title
                plugintools.add_item( action = action , plot = fixed , title = '[B][COLOR yellow]' + fixed + '[COLOR lightyellow][/B][I] Nuevo![/COLOR][/I]' , fanart = art+'fanart.png' , thumbnail = art + 'm3u.png' , url = url , folder = True , isPlayable = False )
    
            if thumbnail == 'special.png':  # Control para listas múltiples tipo XBMCyMás o SPlive
                fixed = title
                plugintools.add_item( action = action , plot = fixed , title = '[B][COLOR blue]' + fixed + '[COLOR lightyellow][/B][I] Nuevo![/COLOR][/I]' , fanart = art+'fanart.png' , thumbnail = art + 'special.png' , url = url , folder = True , isPlayable = False )
    
            if thumbnail == 'icon.png':
                thumbnail = art + thumbnail  # Ajustamos path del thumbnail
                fixed = title
                plugintools.add_item( action = action , plot = fixed , title = '[B][COLOR lightyellow]' + fixed + '[/COLOR][/B]' , fanart = art + 'fanart.png' , thumbnail = art + 'icon.png' , url = url , folder = True , isPlayable = False )
                

def play(params):
    plugintools.play_resolved_url( params.get("url") )


def runPlugin(url):
    xbmc.executebuiltin('XBMC.RunPlugin(' + url +')')


def live_items_withlink(params):
    plugintools.log("palcoTV.live_items_withlink "+repr(params))
    data = plugintools.read(params.get("url"))
    # ToDo: Agregar función lectura de cabecera (fanart, thumbnail, título, últ. actualización)
    matches = plugintools.find_multiple_matches(data,'<item>(.*?)</item>')
    for entry in matches:
        title = plugintools.find_single_match(entry,'<title>(.*?)</title>')
        thumbnail = plugintools.find_single_match(entry,'<thumbnail>(.*?)</thumbnail>')
        url = plugintools.find_single_match(entry,'<link>(.*?)</link>')
        fanart = plugintools.find_single_match(entry, '<fanart>(.*?)</fanart>')
        plugintools.add_item(action = "play" , title = title , url = url , fanart = fanart , folder = False , isPlayable = True )
        

  
def xml_lists(params):
    plugintools.log("palcoTV.SPlive_listas "+repr(params))
    data = plugintools.read( params.get("url") )
    name_channel = params.get("plot")
    pattern = '<name>'+name_channel+'(.*?)</channel>'
    data = plugintools.find_single_match(data, pattern)
    plugintools.add_item( action="" , title='[B][COLOR yellow]'+name_channel+'[/B][/COLOR]' , thumbnail= art + 'splive.png' , folder = False , isPlayable = False )

    subchannel = re.compile('<subchannel>([^<]+)<name>([^<]+)</name>([^<]+)<thumbnail>([^<]+)</thumbnail>([^<]+)<url>([^<]+)</url>([^<]+)</subchannel>').findall(data)
    for biny, ciny, diny, winy, pixy, dixy, boxy in subchannel:
        plugintools.add_item( action="xml_items" , title = ciny , url= dixy , thumbnail = winy , fanart = art + 'fanart.png' , folder = True , isPlayable = False )

       
def getstreams_now(params):
    plugintools.log("palcoTV.getstreams_now "+repr(params))
    
    data = plugintools.read( params.get("url") )
    poster = plugintools.find_single_match(data, '<poster>(.*?)</poster>')
    plugintools.add_item(action="" , title='[COLOR blue][B]'+poster+'[/B][/COLOR]', url="", folder =False, isPlayable=False)
    matches = plugintools.find_multiple_matches(data,'<title>(.*?)</link>')
    
    for entry in matches:
        title = plugintools.find_single_match(entry,'(.*?)</title>')
        url = plugintools.find_single_match(entry,'<link> ([^<]+)')
        plugintools.add_item( action="play" , title=title , url=url , folder = False , isPlayable = True )
        
      
def p2plinks(params):
    plugintools.log("palcoTV.livetv "+repr(params))
      
    data = plugintools.read( params.get("url") )
    matches = plugintools.find_multiple_matches(data,'<item>(.*?)</item>')
    for entry in matches:
        title = plugintools.find_single_match(entry,'<title>(.*?)</title>')
        thumbnail = plugintools.find_single_match(entry,'<thumbnail>(.*?)</thumbnail>')
        ace_url = plugintools.find_single_match(entry,'<link>(.*?)</link>')
        last_update = plugintools.find_single_match(entry,'<date>(.*?)</date>')
        url = 'plugin://plugin.video.p2p-streams/?url=' + ace_url + '&mode=1&name=' + title + ')'
        plugintools.add_item( action="play" , title='[COLOR white]'+title+'[/COLOR]' , url=url , thumbnail=art + thumbnail , folder = False , isPlayable = True )
        

# Soporte de listas de canales por categorías (Livestreams, XBMC México, Motor SportsTV, etc.). 

def livestreams_channels(params):
    plugintools.log("palcoTV.livestreams_channels "+repr(params))
    data = plugintools.read( params.get("url") )
       
    # Extract directory list
    thumbnail = params.get("thumbnail")
    
    if thumbnail == "":
        thumbnail = 'icon.jpg'
        plugintools.log(thumbnail)
    else:
        plugintools.log(thumbnail)
    
    if thumbnail == art + 'icon.png':
        matches = plugintools.find_multiple_matches(data,'<channel>(.*?)</channel>')
        for entry in matches:
            title = plugintools.find_single_match(entry,'<name>(.*?)</name>')
            thumbnail = plugintools.find_single_match(entry,'<thumbnail>(.*?)</thumbnail>')
            fanart = plugintools.find_single_match(entry,'<fanart>(.*?)</fanart>')
            plugintools.add_item( action="livestreams_subchannels" , title=title , url=params.get("url") , thumbnail=thumbnail , fanart=fanart , folder = True , isPlayable = False )

    else:
        matches = plugintools.find_multiple_matches(data,'<channel>(.*?)</channel>')
        for entry in matches:
            title = plugintools.find_single_match(entry,'<name>(.*?)</name>')
            thumbnail = plugintools.find_single_match(entry,'<thumbnail>(.*?)</thumbnail>')
            fanart = plugintools.find_single_match(entry,'<fanart>(.*?)</fanart>')
            plugintools.add_item( action="livestreams_items" , title=title , url=params.get("url") , fanart=fanart , thumbnail=thumbnail , folder = True , isPlayable = False )
   
        
def livestreams_subchannels(params):
    plugintools.log("palcoTV.livestreams_subchannels "+repr(params))

    data = plugintools.read( params.get("url") )
    title_channel = params.get("title")
    name_subchannel = '<name>'+title_channel+'</name>'
    data = plugintools.find_single_match(data, name_subchannel+'(.*?)</channel>')
    info = plugintools.find_single_match(data, '<info>(.*?)</info>')
    title = params.get("title")
    plugintools.set_view(plugintools.LIST)
    plugintools.add_item( action="" , title='[B]'+title+'[/B] [COLOR yellow]'+info+'[/COLOR]' , folder = False , isPlayable = False )

    subchannel = plugintools.find_multiple_matches(data , '<name>(.*?)</name>')
    for entry in subchannel:
        plugintools.add_item( action="livestreams_subitems" , title=entry , url=params.get("url") , thumbnail=art+'motorsports-xbmc.jpg' , folder = True , isPlayable = False )


# Pendiente de cargar thumbnail personalizado y fanart...
def livestreams_subitems(params):
    plugintools.log("palcoTV.livestreams_subitems "+repr(params))

    title_subchannel = params.get("title")
    data = plugintools.read( params.get("url") )
    source = plugintools.find_single_match(data , title_subchannel+'(.*?)<subchannel>')

    titles = re.compile('<title>([^<]+)</title>([^<]+)<link>([^<]+)</link>').findall(source)
    url = params.get("url")
    title = params.get("title")
    thumbnail = params.get("thumbnail")
    
    for entry, quirry, winy in titles:
        winy = winy.replace("amp;","")
        plugintools.add_item( action="play" , title = entry , url = winy , thumbnail = thumbnail , folder = False , isPlayable = True )


def livestreams_items(params):
    plugintools.log("palcoTV.livestreams_items "+repr(params))

    title_subchannel = params.get("title")
    title_subchannel_fixed = plugintools.find_single_match(title_subchannel, ']([^[]+)')
    
    if title_subchannel_fixed == "":
        title_subchannel_fixed = title_subchannel
    else:
        plugintools.log("titulo categoria fixed= "+title_subchannel_fixed)
           
    data = plugintools.read( params.get("url") )
    
    pattern = title_subchannel_fixed+'(.*?)channel>'
    source = plugintools.find_single_match(data , pattern)

    titles = re.compile('<title>([^<]+)</title>([^<]+)<link>([^<]+)</link>([^<]+)<thumbnail>([^<]+)</thumbnail>').findall(source)
    
    url = params.get("url")
    title = params.get("title")
    thumbnail = params.get("thumbnail")
    
    for entry, quirry, winy, xiry, miry in titles:
        winy = winy.replace("amp;","")
        plugintools.add_item( action="play" , title = entry , url = winy , thumbnail = miry , folder = False , isPlayable = True )


def xml_items(params):
    plugintools.log("palcoTV.xml_items "+repr(params))
    data = plugintools.read( params.get("url") )
    thumbnail = params.get("thumbnail")

    #Todo: Implementar una variable que permita seleccionar qué tipo de parseo hacer
    if thumbnail == "title_link.png":
        matches = plugintools.find_multiple_matches(data,'<item>(.*?)</item>')
        for entry in matches:
            title = plugintools.find_single_match(entry,'<title>(.*?)</title>')
            thumbnail = plugintools.find_single_match(entry,'<thumbnail>(.*?)</thumbnail>')
            url = plugintools.find_single_match(entry,'<link>([^<]+)</link>')
            plugintools.add_item( action = "play" , title = title , url = url , thumbnail = thumbnail , folder = False , isPlayable = True )

    if thumbnail == "name_rtmp.png":
        matches = plugintools.find_multiple_matches(data,'<channel>(.*?)</channel>')
        for entry in matches:
            title = plugintools.find_single_match(entry,'<name>(.*?)</name>')
            url = plugintools.find_single_match(entry,'<rtmp>([^<]+)</rtmp>')
            plugintools.add_item( action = "play" , title = title , url = url , folder = False , isPlayable = True )

             
def simpletv_items(params):
    plugintools.log("palcoTV.simpletv_items "+repr(params))
    thumbnail = params.get("thumbnail")
    filename = params.get("title")
    file = open(playlists + filename, "r")
    num_items = len(file.readlines())
    file.seek(0)
    title = params.get("title")

    # Cabecera de la lista
    plugintools.add_item(action="" , title = '[COLOR lightyellow][B]'+ title +'[/B][/COLOR]' , url = "" , folder = False , isPlayable = False )
    

     # Empezamos a leer las lineas del archivo en busca de items
    i = 1
    while i <= num_items:
        data = file.readline()
        print data.startswith("#EXTINF:-1,")
        
        if data.startswith("#EXTINF:-1") == True:
            data = data.lstrip("#EXTINF:-1")
            title = data.strip()
            title = title.replace(",", "")
            data = data.lstrip(",")
            data = file.readline()
            if data.startswith("http") == True:
                url = data
                plugintools.add_item( action = "play" , title = title , url = url , folder = False , isPlayable = True )
                plugintools.log("url_http= "+url)
                i = i + 1
                continue
            else:
                if data.startswith("rtmp://$OPT:rtmp-raw") == True:
                        str_url = data.strip()
                        url_fixed = str_url.lstrip("rtmp://$OPT:rtmp-raw")
                        url = url_fixed.lstrip("=")
                        i = i + 1
                        plugintools.add_item( action = "play" , title = title , url = url , folder = False , isPlayable = True )
                        plugintools.log("url_rtmp= "+url)
                        continue
                else:
                    if data.startswith("rtmp") == True:
                        data = url
                        plugintools.add_item( action = "play" , title = title , url = url , folder = False , isPlayable = True )
                        plugintools.log("url_rtmp= "+url)
                        i = i + 1
                        continue
                
                if data == "":
                    data = file.readline()
        else:
            if data == "":
                i = i + 1
                continue  
            

def myplaylists_m3u(params):  # Mis listas M3U
    plugintools.log("palcoTV.myplaylists_m3u "+repr(params))
    thumbnail = params.get("thumbnail")
    plugintools.add_item(action="play" , title = "[COLOR lightyellow][B]Tutorial: Importar listas M3U a mi biblioteca [COLOR blue][B][Youtube][/B][/COLOR]" , thumbnail = art + "icon.png" , url = "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=8i0KouM-4-U" , folder = False , isPlayable = True )

    ficheros = os.listdir(playlists)  # Lectura de archivos en carpeta /playlists. Cuidado con las barras inclinadas en Windows
    for entry in ficheros:        
        plugintools.add_item(action="simpletv_items" , title = entry , url = playlists + entry , thumbnail = thumbnail )


def playlists_m3u(params):  # Listas online M3U
    plugintools.log("palcoTV.playlists_m3u "+repr(params))
    data = plugintools.read( params.get("url") )
    name_channel = params.get("plot")
    plugintools.log("name_channel= "+name_channel)
    pattern = '<name>'+name_channel+'(.*?)</channel>'
    data = plugintools.find_single_match(data, pattern)
    plugintools.log("data= "+data)
    plugintools.add_item( action="" , title='[B][COLOR yellow]'+name_channel+'[/B][/COLOR]' , thumbnail= art + 'icon.png' , folder = False , isPlayable = False )
    plugintools.add_item( action="" , title='[COLOR lightyellow]Al descargar una lista estará accesible en [B][I]mis listas M3U[/I][/B][/COLOR]' , thumbnail= art + 'icon.png' , folder = False , isPlayable = False )
    plugintools.add_item( action="" , title='[I][COLOR red]Ten paciencia! La descarga tarda unos segundos ;)[/I][/COLOR]' , thumbnail= art + 'icon.png' , folder = False , isPlayable = False )

    subchannel = re.compile('<subchannel>([^<]+)<name>([^<]+)</name>([^<]+)<thumbnail>([^<]+)</thumbnail>([^<]+)<url>([^<]+)</url>([^<]+)</subchannel>').findall(data)
    for biny, ciny, diny, winy, pixy, dixy, boxy in subchannel:
        plugintools.add_item( action="getfile_http" , title = ciny , url= dixy , thumbnail = art + winy , fanart = art + 'fanart.png' , folder = True , isPlayable = False )



def getfile_http(params):  # Descarga de lista M3U + llamada a simpletv_items para que liste los items
    plugintools.log("palcoTV.getfile_http "+repr(params))
    url = params.get("url")
    file = urllib2.urlopen(url)
    size_bytes = file.info()
    filesize = size_bytes.getheaders("Content-Length")[0]
    filesize = int(filesize) * 1024
    print filesize
    byte = 1
    filename = params.get("title") + '.txt'
    arch = open(playlists + filename, 'wb')
    
    # Añadir cuadro de diálogo de espera

    while (byte != filesize):
        arch.write(file.read(byte))
        byte = byte + 1

    plugintools.add_item(action="simpletv_items" , title = filename , url = filename , folder = True , isPlayable = False )
    

run()

